npm create vite@latest frontend --template react
cd frontend
npm install axios react-router-dom tailwindcss @headlessui/react
npx tailwindcss init -p